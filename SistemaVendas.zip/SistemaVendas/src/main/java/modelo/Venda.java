/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import static modelo.MetodoPagamento.CARTAO;
import static modelo.MetodoPagamento.DINHEIRO;
import static modelo.MetodoPagamento.PIX;


public class Venda{
    
    private Long id;
    
    private Vendedor vendedor;
    private Cliente cliente;
     
    Map<ItemVenda, Item> itens;
    
    private Date data;
    private MetodoPagamento metodoPagamento;


    public Venda() {
        this.itens = new HashMap<>();
      
    }

    public Venda(Long id, Vendedor vendedor, Cliente cliente, Date data, MetodoPagamento metodoPagamento) {
        this.itens = new HashMap<>();
        this.id = id;
        this.vendedor = vendedor;
        this.cliente = cliente;
        this.data = data;
        this.metodoPagamento = metodoPagamento;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    
    public Date getData() {
        return data;
    }

    public void setData(Date data) {
        this.data = data;
    }

    public MetodoPagamento getMetodoPagamento() {
        return metodoPagamento;
    }

    public void setMetodoPagamento(MetodoPagamento metodoPagamento) {
        this.metodoPagamento = metodoPagamento;
    }

    public List<ItemVenda> getItens() {
        return (List<ItemVenda>) itens;
    }

    public void setItens(List<ItemVenda> itens) {
        this.itens = (Map<ItemVenda, Item>) itens;
    }
   
   public BigDecimal getValorTotal(){
      BigDecimal total = new BigDecimal("0");
      for(Item item : this.itens.values()){
          total = total.add(item.calcularValor(total));
      }
      return total;
   }


   public void getEnderecoEntrega(){
       
       this.cliente.getEndereco();
       
   }
   
   public int getQtdItens(){
       
       return itens.size();

       
   }
   
   public void pagar(){
       if (null != metodoPagamento)switch (metodoPagamento) {
            case PIX:
                System.out.println("Pagando com o Pix");
                break;
            case DINHEIRO:
                System.out.println("Pagando com Dinheiro");
                break;
            case CARTAO:
                System.out.println("Pagando com Cartão");
                break;
            default:
                break;
        }
   }

    public Vendedor getVendedor() {
        return vendedor;
    }

    public void setVendedor(Vendedor vendedor) {
        this.vendedor = vendedor;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }
    

    }

   