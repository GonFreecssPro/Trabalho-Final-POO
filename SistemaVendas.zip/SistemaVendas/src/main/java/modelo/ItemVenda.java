/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.math.BigDecimal;



public class ItemVenda{
    
    private Long id; 
    private BigDecimal quantidade;
    private Item item;
    private Venda venda;
    

    public ItemVenda() {
    }

    public ItemVenda(Long id, BigDecimal quantidade, Item item, Venda venda) {
        this.id = id;
        this.quantidade = quantidade;
        this.item = item;
        this.venda = venda;
    }

    

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    
    public Item getItem() {
        return item;
    }

    public void setItem(Item item) {
        this.item = item;
    }

    public BigDecimal getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(BigDecimal quantidade) {
        this.quantidade = quantidade;
    }

   

    public Venda getVenda() {
        return venda;
    }

    public void setVenda(Venda venda) {
        this.venda = venda;
    }
    
    public BigDecimal calcularTotal() {
		return this.getItem().calcularValor(this.getQuantidade());
	}

 
   
}
