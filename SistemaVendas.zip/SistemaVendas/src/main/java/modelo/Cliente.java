/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;


import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;


/**
 *
 * @author isaia
 */
@Entity
@PrimaryKeyJoinColumn(name="idPessoa")
public class Cliente extends Pessoa{

   
    @Column(length = 20, nullable = true)
    private String endereco;

    public Cliente() {
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public Cliente(Long idPessoa, String nome, String cpf, String endereco) {
        super(idPessoa, nome, cpf);
        this.endereco = endereco;
    }

    


    
    
}
