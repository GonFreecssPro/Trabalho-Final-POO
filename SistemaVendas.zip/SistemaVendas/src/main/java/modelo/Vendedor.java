/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.text.NumberFormat;
import java.util.Locale;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;


/**
 *
 * @author isaia
 */
@Entity
@PrimaryKeyJoinColumn(name="idPessoa")
public class Vendedor extends Pessoa{

    @Column(name = "SALARIO")
    private double salario;

    public Vendedor() {
    }

    public Vendedor(Long idPessoa, String nome, String cpf, double salario ) {
        super(idPessoa, nome, cpf);
        this.salario = salario;
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }

}
