/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controllers;

import Dao.ItemJpaController;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Scanner;
import javax.persistence.Persistence;
import modelo.Item;

/**
 *
 * @author isaia
 */
public class ItemFunction { 
   private final ItemJpaController dao = new ItemJpaController(
			Persistence.createEntityManagerFactory(
			"loja"));
    private static final BufferedReader entrada2 =   
			new BufferedReader(new InputStreamReader(System.in));
	private static final Scanner entrada =   
			new Scanner(System.in);
	private void exibir(Item i){
		System.out.println("ID: "+i.getIditem()+
                                         "\nItem: "+i.getNome()+
					"\nUnidade: "+i.getUnidade()+
					"\tValor: "+"R$"+i.getValor()+
                                        "\n==========================");
	}
        public void exibirTodos(){
		dao.findItemEntities().forEach(itens->exibir(itens));
	}
	public void inserirItem() throws Exception{
		Item i = new Item();
		System.out.println("Nome:");
		i.setNome(entrada.nextLine());
		System.out.println("UNIDADE:");
		i.setUnidade(entrada.nextLine());
                System.out.println("Valor: ");
		i.setValor(entrada.nextBigDecimal());
		dao.create(i);
	}
	public void excluirItem() throws Exception{
		System.out.println("ID:");
		Integer id = (Integer.parseInt(entrada2.readLine()));
		dao.destroy(id);
	}      
        
         public void alterarItem(Long id) throws Exception{
            Item c2 = new Item();
            System.out.println("id do item: ");
            c2.setIditem(entrada.nextInt());
            System.out.println("Novo Nome: ");
            c2.setNome(entrada2.readLine());
            System.out.println("Nova Unidade: ");
            c2.setUnidade(entrada2.readLine());
            System.out.println("Novo Valor: ");
            c2.setValor(entrada.nextBigDecimal());
            dao.edit(c2);
            
        }
           
 public void itemFunction() throws Exception{
         ItemFunction sistema = new ItemFunction();
        while(true){
            System.out.println("\"============================\"");
            System.out.println("\"=========ITENS:==========\"");
            System.out.println("\"=============================\"");
            System.out.println(                  
            "1-exibir\t2-inserir\t3-excluir\t4-alterar\t0-Sair");
            int opcao = Integer.parseInt(entrada2.readLine());          
            if(opcao==0)
                break;
            switch(opcao){
                case 1: sistema.exibirTodos();
                break;
                case 2: sistema.inserirItem();
                break;
                case 3: sistema.excluirItem();
               break;              
                case 4: sistema.alterarItem(Long.MIN_VALUE);
                break;
            }
        }
    }
}
