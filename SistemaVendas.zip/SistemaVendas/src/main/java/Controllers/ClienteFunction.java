/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controllers;

import Dao.ClienteJpaController;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Scanner;
import javax.persistence.Persistence;
import modelo.Cliente;

/**
 *
 * @author isaia
 */
public class ClienteFunction {
     private final ClienteJpaController dao = new ClienteJpaController(
			Persistence.createEntityManagerFactory(
			"loja"));
	private static final BufferedReader entrada =   
			new BufferedReader(new InputStreamReader(System.in));
		private static final Scanner entrada2 =   
			new Scanner(System.in);
	private void exibir(Cliente c){
		System.out.println("ID: "+c.getIdPessoa()+
                                        "\nCliente: "+c.getNome()+
					"\nCPF: "+c.getCpf()+
					"\tEndereço: "+c.getEndereco()+
                                            "\n==========================");
	}
        public void exibirTodos(){
		dao.findClienteEntities().forEach(clientes->exibir(clientes));
	}
	public void inserirCliente() throws Exception{
		Cliente c = new Cliente();             
		System.out.println("Nome:");
		c.setNome(entrada.readLine());
		System.out.println("CPF:");
		c.setCpf(entrada.readLine());
		System.out.println("Endereço:");
		c.setEndereco(entrada.readLine());
		dao.create(c);
	}
	public void excluirCliente() throws Exception{
		System.out.println("ID:");
                Long id = (Long.parseLong(entrada.readLine()));
		dao.destroy(id);
	}           
        
        public void alterarCliente(Long id) throws Exception{
            Cliente c2 = new Cliente();
            System.out.println("id da pessoa: ");
            c2.setIdPessoa(entrada2.nextLong());
            System.out.println("Novo Nome: ");
            c2.setNome(entrada.readLine());
            System.out.println("Novo cpf: ");
            c2.setCpf(entrada.readLine());
            System.out.println("Novo endereço: ");
            c2.setEndereco(entrada.readLine());  
            dao.edit(c2);
            
        }
           
 public void clienteFunction() throws Exception{
         ClienteFunction sistema = new ClienteFunction();
        while(true){
            System.out.println("\"============================\"");
            System.out.println("\"=========CLIENTES:==========\"");
            System.out.println("\"=============================\"");
            System.out.println(                  
            "1-exibir\t2-inserir\t3-excluir\t4-Alterar\t0-Sair");
            int opcao = Integer.parseInt(entrada.readLine());
            if(opcao==0)
                break;
            switch(opcao){
                case 1: sistema.exibirTodos();
                break;
                case 2: sistema.inserirCliente();
                break;
                case 3: sistema.excluirCliente();
               break;
                case 4: sistema.alterarCliente(Long.MIN_VALUE);
               break;
            }
        }
    }
}
