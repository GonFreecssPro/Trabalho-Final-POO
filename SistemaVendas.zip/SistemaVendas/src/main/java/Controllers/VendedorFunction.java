/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controllers;

import Dao.VendedorJpaController;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Scanner;
import javax.persistence.Persistence;
import modelo.Vendedor;

/**
 *
 * @author isaia
 */
public class VendedorFunction {
    private final VendedorJpaController dao = new VendedorJpaController(
			Persistence.createEntityManagerFactory(
			"loja"));
    
    private static final BufferedReader entrada2 =   
			new BufferedReader(new InputStreamReader(System.in));
    
	private static final Scanner entrada =   
			new Scanner(System.in);
	private void exibir(Vendedor d){
		System.out.println("ID: "+d.getIdPessoa()+
                                        "\nVendedor: "+d.getNome()+
					"\nCPF: "+d.getCpf()+
					"\tSalário: "+"R$"+d.getSalario()+ 
                                          "\n==========================");
	}
        public void exibirTodos(){
		dao.findVendedorEntities().forEach(vendedor->exibir(vendedor));
	}
	public void inserirVendedor() throws Exception{
		Vendedor d = new Vendedor();
		System.out.println("Nome:");
		d.setNome(entrada.nextLine());
		System.out.println("CPF:");
		d.setCpf(entrada.nextLine());
                System.out.println("Salario: ");
		d.setSalario(entrada.nextDouble());
		dao.create(d);
	}
	public void excluirVendedor() throws Exception{
		System.out.println("ID:");
		Long id = (Long.parseLong(entrada2.readLine()));
		dao.destroy(id);
	}           
        
        public void alterarVendedor(Long id) throws Exception{
            Vendedor c2 = new Vendedor();
            System.out.println("id da pessoa: ");
            c2.setIdPessoa(entrada.nextLong());
            System.out.println("Novo Nome: ");
            c2.setNome(entrada2.readLine());
            System.out.println("Novo cpf: ");
            c2.setCpf(entrada2.readLine());
            System.out.println("Novo Salário: ");
            c2.setSalario(entrada.nextDouble());
            dao.edit(c2);
            
        }
           
 public void vendedorFunction() throws Exception{
         VendedorFunction sistema = new VendedorFunction();
        while(true){
            System.out.println("\"============================\"");
            System.out.println("\"=========VENDEDOR:==========\"");
            System.out.println("\"=============================\"");
            System.out.println(                  
            "1-exibir\t2-inserir\t3-excluir\t4-alterar\t0-Sair");
            int opcao = Integer.parseInt(entrada2.readLine());          
            if(opcao==0)
                break;
            switch(opcao){
                case 1: sistema.exibirTodos();
                break;
                case 2: sistema.inserirVendedor();
                break;
                case 3: sistema.excluirVendedor();
               break;
                case 4: sistema.alterarVendedor(Long.MIN_VALUE);
                break;
            }
        }
    }
}
