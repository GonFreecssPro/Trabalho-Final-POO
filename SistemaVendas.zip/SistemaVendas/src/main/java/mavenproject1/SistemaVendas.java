/*
Nome: Isaias Barbosa de Oliveira
Matricula: 202003211877
*/

package mavenproject1;

import Controllers.ClienteFunction;
import Controllers.ItemFunction;
import Controllers.VendedorFunction;

import java.util.Scanner;

public class SistemaVendas {

private static final Scanner entrada2 =   
			new Scanner(System.in);
 
    public static void main(String[] args) throws Exception {

        while(true){
        System.out.println("--------BEM VINDO AO SISTEMA DE VENDAS--------");
        System.out.println("Escolha entre: 1- Clientes, 2- Vendedores, 3- Itens, 0- Sair");
        int op = Integer.parseInt(entrada2.nextLine());
        if (op==0)
            break;
        switch(op){
            case 1: ClienteFunction cliente = new ClienteFunction();
                    cliente.clienteFunction();
            break;
            case 2: VendedorFunction vendedor = new VendedorFunction();
                    vendedor.vendedorFunction();
            break;
            case 3: ItemFunction itens = new ItemFunction();
                    itens.itemFunction();
            break;
         }
      }
    }
}
